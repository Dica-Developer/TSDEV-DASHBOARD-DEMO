module.exports = {
    appPort: 5000,
    sessionProperties: {
        key: 'user_sid',
        secret: 'somerandonstuffs',
        resave: false,
        saveUninitialized: false,
        cookie: {
            expires: 6000000
        }
    },
    maxDataLimit: '100mb',
    maxLogSize: 10000000,
    defaultAdminUserName: 'admin',
    defaultAdminPassword: 'admin'
};
